export interface IConstantType {
  _id: string;
  name: string;
}
