enum ROLE {
    AI = 'ai',
    HUMAN = 'human',
}
export default ROLE;
