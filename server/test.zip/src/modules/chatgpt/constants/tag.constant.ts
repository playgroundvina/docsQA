const ModelTag = `chat gpt`;
export default ModelTag;
