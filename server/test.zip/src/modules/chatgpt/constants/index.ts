import tag from './tag.constant';
import path from './path.constant';
import endpoint from './endpoint.constant';
import role from './role.constant';

export default {
  tag,
  path,
  endpoint,
  role,
};
