import createDto from './create.dto';
import updateDto from './update.dt';
export default {
  createDto,
  updateDto,
};
