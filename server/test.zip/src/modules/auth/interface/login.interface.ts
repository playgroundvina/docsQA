export interface LoginSuccess {
  id: string;
  role: string;
  fullName: string;
  accessToken: string;
  refreshToken: string;
}
