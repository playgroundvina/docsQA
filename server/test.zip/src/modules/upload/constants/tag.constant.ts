const ModelTag = `Upload file`;
export default ModelTag;
