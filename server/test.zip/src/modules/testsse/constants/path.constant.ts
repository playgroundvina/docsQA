import { APP_CONSTANT } from 'src/shared/constants/app.constant';
// thường thì sẽ để từ số nhiều
const ModelPath = `${APP_CONSTANT.APP_PREFIX}/testsse/`;
export default ModelPath;
