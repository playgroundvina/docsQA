const ModelTag = `Model`;
export default ModelTag;
