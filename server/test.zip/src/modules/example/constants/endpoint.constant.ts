enum Model_API {
  CREATE = '',
  FIND_ALL = '',
  FIND_BY_ID = ':id',
  UPDATE = ':id',
  REMOVE = ':id',
}

export default Model_API;
