import tag from './tag.constant';
import path from './path.constant';
import endpoint from './endpoint.constant';

export default {
  tag,
  path,
  endpoint,
};
