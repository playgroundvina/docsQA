export interface DocType {
  [key: string]: any;
}
export interface RetType {
  [key: string]: any;
}
